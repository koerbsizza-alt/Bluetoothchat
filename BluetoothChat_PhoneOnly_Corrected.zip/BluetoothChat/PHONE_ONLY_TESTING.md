# Bluetooth Chat — Phone-Only Testing

This project is designed to be built and tested directly on Android using a mobile Android IDE such as AndroidIDE. No Internet permission is included in the app.

## What you need
- Two Android phones with Bluetooth.
- A mobile Android IDE that can import Gradle Android projects.
- Android SDK 35 and JDK 17 available in that IDE.

## Build on the phone
1. Install AndroidIDE from a trusted source. The original AndroidIDE project is archived, so treat third-party builds cautiously.
2. Copy/extract this project into a folder accessible to the IDE.
3. Open the `BluetoothChat` folder as a Gradle project.
4. Let Gradle sync/download dependencies.
5. Build the **debug** APK (`assembleDebug` / Build APK).
6. Install the generated debug APK on both phones.

## Test chat
1. On both phones, open **Settings → Bluetooth** and pair the phones.
2. Open Bluetooth Chat on both phones and grant Bluetooth permissions.
3. On Phone A tap **Wait for connection**.
4. On Phone B tap **Find devices**. The paired phone should appear. Tap it.
5. Send a text message from either phone.
6. Tap **Send photo** to transfer an image.

## Important
- Bluetooth must be enabled on both phones.
- The app communicates through Bluetooth Classic RFCOMM only. It does not use the Internet.
- The phones need to remain reasonably close to each other.
- Received images are stored in the app's Pictures/Received folder.
- The debug APK is unsigned with a release key, which is fine for local testing.
