# Build the APK from a phone using GitHub Actions

This project is configured to build a debug APK with GitHub Actions.

## Important
GitHub Actions only discovers workflow files that are committed in the repository at:

`.github/workflows/build-debug-apk.yml`

If you upload this ZIP as one file, GitHub will **not** automatically treat the workflow inside the ZIP as a repository workflow. Either:

- upload/extract the project files so `.github/workflows/build-debug-apk.yml` exists at the repository root, or
- keep the separate workflow file you created in your repository.

## Build

1. Open the repository's **Actions** tab.
2. Select **Build Bluetooth Chat APK**.
3. Tap **Run workflow** and select `main`, or push a change to `main`.
4. Open the completed run.
5. Download the artifact named **BluetoothChat-debug-apk**.
6. Extract the artifact ZIP and install `app-debug.apk` on the Android phone.

The workflow uses Java 17, Gradle 8.9, Android SDK 35, and builds `app-debug.apk`.


## Build compatibility fix
This version uses the Android platform Activity and Material theme instead of AppCompat, so it has no Kotlin stdlib dependency conflict during the GitHub Actions build.
