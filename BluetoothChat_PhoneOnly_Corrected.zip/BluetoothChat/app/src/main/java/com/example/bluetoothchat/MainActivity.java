package com.example.bluetoothchat;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothDevice;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.*;
import java.util.*;

public class MainActivity extends AppCompatActivity implements BluetoothService.Callback {

    private static final int REQ_PERMS = 50;
    private static final int PICK_PHOTO = 60;

    private BluetoothAdapter adapter;
    private BluetoothService service;
    private ArrayAdapter<String> deviceAdapter;
    private final ArrayList<BluetoothDevice> devices = new ArrayList<>();
    private boolean receiverRegistered = false;

    private TextView statusText;
    private LinearLayout chatContainer;
    private ScrollView chatScroll;
    private EditText messageInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusText = findViewById(R.id.statusText);
        chatContainer = findViewById(R.id.chatContainer);
        chatScroll = findViewById(R.id.chatScroll);
        messageInput = findViewById(R.id.messageInput);

        BluetoothManager bm = (BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
        adapter = bm.getAdapter();

        deviceAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1);
        ListView list = findViewById(R.id.deviceList);
        list.setAdapter(deviceAdapter);

        service = new BluetoothService(adapter, this);

        findViewById(R.id.discoverButton).setOnClickListener(v -> discover());
        findViewById(R.id.listenButton).setOnClickListener(v -> listen());
        findViewById(R.id.sendButton).setOnClickListener(v -> sendMessage());

        findViewById(R.id.photoButton).setOnClickListener(v -> choosePhoto());

        list.setOnItemClickListener((parent, view, position, id) -> {
            if (position < devices.size()) service.connect(devices.get(position));
        });

        if (Build.VERSION.SDK_INT >= 31) {
            requestPermissions(new String[]{
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
            }, REQ_PERMS);
        } else if (!adapter.isEnabled()) {
            startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE));
        }
    }

    private boolean allowed() {
        return Build.VERSION.SDK_INT < 31 ||
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)
                        == PackageManager.PERMISSION_GRANTED;
    }

    private void discover() {
        if (!allowed()) {
            requestPermissions(new String[]{
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
            }, REQ_PERMS);
            return;
        }
        if (!adapter.isEnabled()) {
            startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE));
            return;
        }

        devices.clear();
        deviceAdapter.clear();

        for (BluetoothDevice d : adapter.getBondedDevices()) {
            devices.add(d);
            deviceAdapter.add(safeName(d) + "\nPaired");
        }

        if (Build.VERSION.SDK_INT >= 31 &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)
                        != PackageManager.PERMISSION_GRANTED) return;

        if (adapter.isDiscovering()) adapter.cancelDiscovery();
        adapter.startDiscovery();

        if (!receiverRegistered) {
            IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED);
            } else {
                registerReceiver(receiver, filter);
            }
            receiverRegistered = true;
        }
        statusText.setText("Searching... paired devices are already listed. Tap a device to connect.");
    }

    private String safeName(BluetoothDevice d) {
        try {
            String n = d.getName();
            return n == null ? d.getAddress() : n;
        } catch (SecurityException e) {
            return "Bluetooth device";
        }
    }

    private void listen() {
        service.listen();
        statusText.setText("Waiting for another phone...");
    }

    private void sendMessage() {
        String s = messageInput.getText().toString().trim();
        if (s.isEmpty()) return;

        if (service.sendText(s)) {
            addChat("Me: " + s);
            messageInput.setText("");
        } else {
            Toast.makeText(this, "Not connected", Toast.LENGTH_SHORT).show();
        }
    }

    private void choosePhoto() {
        if (!service.isConnected()) {
            Toast.makeText(this, "Connect to a phone first", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        startActivityForResult(i, PICK_PHOTO);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_PHOTO && resultCode == Activity.RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri == null) return;

            try {
                getContentResolver().takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {}

            new Thread(() -> {
                try {
                    String name = "photo_" + System.currentTimeMillis() + ".jpg";
                    InputStream in = getContentResolver().openInputStream(uri);
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                    in.close();

                    byte[] bytes = out.toByteArray();
                    if (bytes.length > 25 * 1024 * 1024) {
                        runOnUiThread(() -> Toast.makeText(this,
                                "Photo is larger than 25 MB", Toast.LENGTH_SHORT).show());
                        return;
                    }

                    boolean ok = service.sendPhoto(name, bytes);
                    runOnUiThread(() -> {
                        if (ok) addChat("Me: 📷 " + name);
                        else Toast.makeText(this, "Photo send failed",
                                Toast.LENGTH_SHORT).show();
                    });
                } catch (Exception e) {
                    runOnUiThread(() -> Toast.makeText(this,
                            "Could not read photo", Toast.LENGTH_SHORT).show());
                }
            }).start();
        }
    }

    private void addChat(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(16);
        tv.setPadding(8, 10, 8, 10);
        chatContainer.addView(tv);
        chatScroll.post(() -> chatScroll.fullScroll(View.FOCUS_DOWN));
    }

    @Override public void onConnected(String name) {
        runOnUiThread(() -> {
            statusText.setText("Connected to " + name);
            addChat("System: Connected to " + name);
        });
    }

    @Override public void onDisconnected() {
        runOnUiThread(() -> {
            statusText.setText("Disconnected");
            addChat("System: Disconnected");
        });
    }

    @Override public void onTextReceived(String text) {
        runOnUiThread(() -> addChat("Them: " + text));
    }

    @Override public void onPhotoReceived(String fileName, byte[] data) {
        runOnUiThread(() -> {
            try {
                File dir = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES),
                        "Received");
                if (!dir.exists()) dir.mkdirs();

                File file = new File(dir, fileName);
                FileOutputStream out = new FileOutputStream(file);
                out.write(data);
                out.close();

                addChat("Them: 📷 " + file.getAbsolutePath());
                Toast.makeText(this, "Photo received", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, "Could not save photo",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!BluetoothDevice.ACTION_FOUND.equals(intent.getAction())) return;

            BluetoothDevice d = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
            if (d == null) return;

            for (BluetoothDevice x : devices) {
                try {
                    if (x.getAddress().equals(d.getAddress())) return;
                } catch (Exception ignored) {}
            }

            devices.add(d);
            deviceAdapter.add(safeName(d) + "\n" + d.getAddress());
            deviceAdapter.notifyDataSetChanged();
        }
    };

    @Override
    protected void onDestroy() {
        if (receiverRegistered) {
            try { unregisterReceiver(receiver); } catch (Exception ignored) {}
            receiverRegistered = false;
        }
        if (adapter != null) {
            try { if (adapter.isDiscovering()) adapter.cancelDiscovery(); } catch (Exception ignored) {}
        }
        if (service != null) service.close();
        super.onDestroy();
    }


}
