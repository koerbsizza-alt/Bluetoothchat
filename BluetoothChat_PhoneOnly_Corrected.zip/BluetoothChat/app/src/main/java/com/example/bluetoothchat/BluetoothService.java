package com.example.bluetoothchat;

import android.bluetooth.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public class BluetoothService {

    public interface Callback {
        void onConnected(String name);
        void onDisconnected();
        void onTextReceived(String text);
        void onPhotoReceived(String fileName, byte[] data);
    }

    // Same UUID must be used by both phones.
    private static final UUID APP_UUID =
            UUID.fromString("7f2f9b7e-6c18-4b4a-9a34-4a8f2a7f5f10");

    private static final int TYPE_TEXT = 1;
    private static final int TYPE_PHOTO = 2;

    private final BluetoothAdapter adapter;
    private final Callback callback;

    private BluetoothServerSocket serverSocket;
    private BluetoothSocket socket;
    private DataInputStream in;
    private DataOutputStream out;

    private final ExecutorService executor =
            Executors.newCachedThreadPool();

    public BluetoothService(BluetoothAdapter adapter, Callback callback) {
        this.adapter = adapter;
        this.callback = callback;
    }

    public void listen() {
        executor.execute(() -> {
            try {
                if (serverSocket != null) serverSocket.close();

                serverSocket = adapter.listenUsingRfcommWithServiceRecord(
                        "BluetoothChat", APP_UUID);

                BluetoothSocket s = serverSocket.accept();
                serverSocket.close();
                serverSocket = null;

                setupSocket(s);
            } catch (Exception e) {
                closeSocket();
            }
        });
    }

    public void connect(BluetoothDevice device) {
        executor.execute(() -> {
            try {
                if (adapter.isDiscovering()) adapter.cancelDiscovery();

                closeSocket();

                BluetoothSocket s =
                        device.createRfcommSocketToServiceRecord(APP_UUID);

                s.connect();
                setupSocket(s);

            } catch (Exception e) {
                closeSocket();
            }
        });
    }

    private synchronized void setupSocket(BluetoothSocket s) throws IOException {
        socket = s;
        in = new DataInputStream(new BufferedInputStream(s.getInputStream()));
        out = new DataOutputStream(new BufferedOutputStream(s.getOutputStream()));

        String name;
        try {
            name = s.getRemoteDevice().getName();
        } catch (SecurityException e) {
            name = "Bluetooth device";
        }

        callback.onConnected(name);

        executor.execute(this::readLoop);
    }

    private void readLoop() {
        try {
            while (socket != null && socket.isConnected()) {
                int type = in.readInt();
                long length = in.readLong();

                if (length < 0 || length > 30L * 1024 * 1024)
                    throw new IOException("Invalid payload");

                if (type == TYPE_TEXT) {
                    byte[] data = readFully((int) length);
                    callback.onTextReceived(new String(data, "UTF-8"));

                } else if (type == TYPE_PHOTO) {
                    if (length < 4 || length > 25L * 1024 * 1024)
                        throw new IOException("Invalid photo");

                    int nameLength = in.readInt();
                    if (nameLength < 1 || nameLength > 255)
                        throw new IOException("Invalid filename");

                    byte[] nameBytes = readFully(nameLength);
                    String name = new String(nameBytes, "UTF-8");

                    long dataLength = length - 4 - nameLength;
                    if (dataLength < 0 || dataLength > 25L * 1024 * 1024)
                        throw new IOException("Invalid photo data");

                    byte[] photo = readFully((int) dataLength);
                    callback.onPhotoReceived(name, photo);
                } else {
                    throw new IOException("Unknown packet");
                }
            }
        } catch (Exception ignored) {
        } finally {
            closeSocket();
            callback.onDisconnected();
        }
    }

    private byte[] readFully(int length) throws IOException {
        byte[] data = new byte[length];
        in.readFully(data);
        return data;
    }

    public synchronized boolean sendText(String text) {
        try {
            byte[] data = text.getBytes("UTF-8");
            writeHeader(TYPE_TEXT, data.length);
            out.write(data);
            out.flush();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public synchronized boolean sendPhoto(String fileName, byte[] photo) {
        try {
            byte[] name = fileName.getBytes("UTF-8");

            if (name.length > 255 ||
                    photo.length > 25 * 1024 * 1024) return false;

            long payloadLength = 4L + name.length + photo.length;

            writeHeader(TYPE_PHOTO, payloadLength);
            out.writeInt(name.length);
            out.write(name);
            out.write(photo);
            out.flush();
            return true;

        } catch (Exception e) {
            return false;
        }
    }

    private void writeHeader(int type, long length) throws IOException {
        if (out == null || socket == null || !socket.isConnected())
            throw new IOException("Not connected");

        out.writeInt(type);
        out.writeLong(length);
    }

    public synchronized boolean isConnected() {
        return socket != null && socket.isConnected() && out != null;
    }

    public synchronized void closeSocket() {
        try { if (socket != null) socket.close(); } catch (Exception ignored) {}
        socket = null;
        in = null;
        out = null;
    }

    public void close() {
        try { if (serverSocket != null) serverSocket.close(); } catch (Exception ignored) {}
        closeSocket();
        executor.shutdownNow();
    }
}
