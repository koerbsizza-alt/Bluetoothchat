# Build this project on Android

1. Install a mobile Android IDE capable of Gradle Android projects.
2. Extract/open the `BluetoothChat` folder.
3. Select the project root (the folder containing `settings.gradle`).
4. Install/use JDK 17 and Android SDK 35 in the IDE.
5. Allow Gradle to sync and download `androidx.appcompat:appcompat:1.7.0` and the Android Gradle Plugin.
6. Run the IDE action for **Build APK / Assemble Debug**.
7. Install the generated `app-debug.apk` on both phones.

The project uses Android Gradle Plugin 8.7.3 and Gradle 8.9 metadata, with `compileSdk 35`, `targetSdk 35`, and `minSdk 23`.

If the IDE asks for an SDK component, install Android SDK Platform 35 and the matching Android build tools.
